<?php

    if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    class TenfoldLeads
    {

        function unformatNumbers($bean, $event, $arguments)
        {

            global $db;
            require_once('custom/include/Tenfold/TenfoldPhoneHelper.php');
            $helper = new TenfoldPhoneHelper();

            // Use method to strip all but digits from phone fields
            $unformatted_other_phone = $helper->stripNumbers($bean->phone_other);
            $unformatted_work_phone = $helper->stripNumbers($bean->phone_work);
            $unformatted_mobile_phone = $helper->stripNumbers($bean->phone_mobile);
            $unformatted_home_phone = $helper->stripNumbers($bean->phone_home);

            $sql = "UPDATE leads_cstm 
                  SET phone_other_unformatted_c = $unformatted_other_phone,
                      phone_work_unformatted_c = $unformatted_work_phone,
                      phone_mobile_unformatted_c = $unformatted_mobile_phone,
                      phone_home_unformatted_c = $unformatted_home_phone
                  WHERE id_c = '$bean->id'";
            $GLOBALS['log']->fatal($sql);
            $db->query($sql);

        }



    }