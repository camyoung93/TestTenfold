<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/9/16
     * Time: 4:00 PM
     * File Name: en_us.unformattedFields.php
     * Project: Tenfold
     */

    $mod_strings['LBL_PHONE_OTHER_UNFORMATTED'] = 'Unformatted Other Phone';
    $mod_strings['LBL_PHONE_WORK_UNFORMATTED'] = 'Unformatted Work Phone';
    $mod_strings['LBL_PHONE_MOBILE_UNFORMATTED'] = 'Unformatted Mobile Phone';
    $mod_strings['LBL_PHONE_HOME_UNFORMATTED'] = 'Unformatted Home Phone';