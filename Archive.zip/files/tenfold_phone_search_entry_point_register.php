<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/12/16
     * Time: 12:34 AM
     * File Name: tenfold_phone_search_entry_point_register.php
     * Project: Tenfold Number Search
     */

    $entry_point_registry['tenfoldNumberSearch'] = array(
        'file' => 'custom/include/Tenfold/searchRecords.php',
        'auth' => true
    );
