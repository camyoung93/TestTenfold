<?php

    if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    class TenfoldAccounts
    {

        function unformatNumbers($bean, $event, $arguments)
        {

            global $db;
            require_once('custom/include/Tenfold/TenfoldPhoneHelper.php');
            $helper = new TenfoldPhoneHelper();


                // Use method to strip all but digits from phone fields
                $unformatted_office_phone = $helper->stripNumbers($bean->phone_office);
                $unformatted_alternate_phone = $helper->stripNumbers($bean->phone_alternate);


                $sql = "UPDATE accounts_cstm 
                      SET phone_alternate_unformatted_c = $unformatted_alternate_phone,
                          phone_office_unformatted_c = $unformatted_office_phone
                      WHERE id_c = '$bean->id'";

            $GLOBALS['log']->fatal("Save Hook Called $sql" );
                $db->query($sql);

        }


    }