<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/9/16
     * Time: 4:00 PM
     * File Name: en_us.unformattedFields.php
     * Project: Tenfold
     */

    $mod_strings['LBL_PHONE_OFFICE_UNFORMATTED'] = 'Unformatted Office Phone';
    $mod_strings['LBL_PHONE_ALTERNATE_UNFORMATTED'] = 'Unformatted Alternate Phone';