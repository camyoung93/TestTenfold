<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/12/16
     * Time: 12:35 AM
     * File Name: searchRecords.php
     * Project: SugarTest
     */

    require_once('custom/include/Tenfold/TenfoldPhoneHelper.php');

    $helper = new TenfoldPhoneHelper();

    $phone = $_REQUEST['searchnumber'];

    $results = $helper->searchNumber($phone);

    echo json_encode($results);