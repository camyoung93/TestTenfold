<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/12/16
     * Time: 12:35 AM
     * File Name: TenfoldPhoneHelper.php
     * Project: Tenfold Number Search
     */

    class TenfoldPhoneHelper
    {

        /**
         * Regex number to return only digits and surround with single quotes for use in query
         * @param $phone
         * @return mixed|string
         */
        function stripNumbers ($phone)
        {

            if ($phone || $phone = '') {
                $unformatted = preg_replace ("/[^0-9]/", "", $phone);

                if ($unformatted == '') {

                    $unformatted = 'NULL';

                } else {

                    $unformatted = "'" . $unformatted . "'";

                }
            } else {
                $unformatted = 'NULL';
            }

            return $unformatted;

        }


        /**
         * Parse number and instance version then return array of results
         * After querying database depending on platform
         * @param $phone
         * @return array
         */
        /*function searchNumber ($phone)
        {

            $number = preg_replace ("/[^0-9]/", "", $phone);

            $results = $this->searchAll($number);

            return $results;
        }*/

        function searchNumber ($phone)
        {
            global $db, $sugar_version, $sugar_config, $current_user;
            $number = preg_replace ("/[^0-9]/", "", $phone);

            if (version_compare ($sugar_version, '7.0', '>=')) {

                $results = $this->searchQuery7 ($number);

            } else {
                if (isset($sugar_config['securitysuite_version']) && $current_user->is_admin != '1') {

                    $results = $this->searchSecurityGroups ($number);

                } else {

                    $results = $this->searchAll($number);
                }
            }

            return $results;
        }

        /**
         * Conduct search on modules using SugarQuery for unformatted fields containing passed number
         * @param $number
         * @return array
         */
        function searchQuery7 ($number)
        {
            //SugarQuery for Accounts
            $SugarQuery1 = new SugarQuery();


            $SugarQuery1->from (BeanFactory::getBean ('Accounts'));
            $SugarQuery1->select (array('id', 'name', 'description', 'email1', 'date_entered', 'industry', 'account_type',
                'assigned_user_id', 'assigned_user_name', 'created_by', 'created_by_name', 'parent_id', 'team_id', 'team_set_id' ));
            $SugarQuery1->select->fieldRaw ("'Accounts' AS", 'module');
            $SugarQuery1->where ()->queryOr ()->contains ('phone_office_unformatted_c', $number)->contains (
                'phone_alternate_unformatted_c',
                $number
            );

            $sql = $SugarQuery1->compileSql();
            $GLOBALS['log']->debug($sql);
            $accounts = $SugarQuery1->execute ();

            //SugarQuery for Contacts
            $SugarQuery2 = new SugarQuery();
            $SugarQuery2->select (array('id', 'date_entered', 'created_by', 'created_by_name', 'description', 'email1', 'first_name', 'last_name',
                'lead_source', 'team_id', 'team_set_id', 'assigned_user_id', 'assigned_user_name'));
            $SugarQuery2->from (BeanFactory::getBean ('Contacts'));
            $SugarQuery2->select->fieldRaw ("CONCAT(contacts.first_name, ' ', contacts.last_name)", 'name');
            $SugarQuery2->select->fieldRaw ("'Contacts' AS", 'module');
            $SugarQuery2->select->fieldRaw('a.name', 'account_name');
            $SugarQuery2->select->fieldRaw('a.id', 'account_id');
            $SugarQuery2->joinRaw('LEFT JOIN accounts_contacts acc ON (contacts.id = acc.contact_id AND acc.deleted = 0 AND acc.primary_account = 1)');
            $SugarQuery2->joinRaw('LEFT JOIN accounts a ON (a.id = acc.account_id AND a.deleted = 0)');
            $SugarQuery2->where ()->queryOr ()->contains ('phone_other_unformatted_c', $number)->contains (
                'phone_work_unformatted_c',
                $number
            )->contains ('phone_mobile_unformatted_c', $number)->contains ('phone_home_unformatted_c', $number);

            $sql = $SugarQuery2->compileSql();
            $GLOBALS['log']->debug($sql);
            $contacts = $SugarQuery2->execute ();


            //SugarQuery For Leads
            $SugarQuery3 = new SugarQuery();
            $SugarQuery3->select (array('id', 'date_entered', 'created_by', 'created_by_name', 'description', 'email1', 'lead_source', 'status', 'account_name', 'account_id', 'contact_id', 'team_id', 'team_set_id',  'assigned_user_id', 'assigned_user_name', 'first_name', 'last_name'));
            $SugarQuery3->from (BeanFactory::getBean ('Leads'));

            $SugarQuery3->select->fieldRaw ("'Leads' AS", 'module');
            $SugarQuery3->select->fieldRaw("CONCAT(leads.first_name, ' ', leads.last_name) AS ", 'lead_name');
            $SugarQuery3->select->fieldRaw("CONCAT(c.first_name, ' ', c.last_name) AS ", 'contact_name');
            $SugarQuery3->joinRaw('LEFT JOIN contacts c ON (leads.contact_id = c.id AND c.deleted = 0)');
            $SugarQuery3->joinRaw('LEFT JOIN accounts a ON (leads.account_id = a.id AND a.deleted = 0)');
            $SugarQuery3->where ()->queryOr ()->contains ('phone_other_unformatted_c', $number)->contains (
                'phone_work_unformatted_c',
                $number
            )->contains ('phone_mobile_unformatted_c', $number)->contains ('phone_home_unformatted_c', $number);
            $sql = $SugarQuery3->compileSql();
            $GLOBALS['log']->debug($sql);
            $leads = $SugarQuery3->execute ();

            $results = array();

            if (count ($accounts) > 0) {

                foreach ($accounts as $account) {
                    $row = array(
                        'id' => $account['id'], 'name' => $account['name'], 'description' => $account['description'] ,
                        'email' => $account['email1'], 'date_entered' => $account['date_entered'], 'industry' => $account['industry'],
                        'account_type' => $account['account_type'], 'assigned_user_id' => $account['assigned_user_id'],
                        'assigned_user_name' => $account['rel_assigned_user_name_first_name'] . ' ' . $account['rel_assigned_user_name_last_name'],
                        'created_by' => $account['created_by'],
                        'created_by_name' => $account['rel_created_by_name_first_name'] . ' ' . $account['rel_created_by_name_last_name'],
                        'parent_id' => $account['parent_id'],'team_id' =>  $account['team_id'], 'team_set_id' => $account['team_set_id'],
                        'module' => 'Accounts'
                    );
                    $results[] = $row;
                }
            }

            if (count ($contacts) > 0) {

                foreach ($contacts as $contact) {

                    $row = array(
                        'id' => $contact['id'], 'name' => $contact['name'], 'first_name' => $contact['first_name'], 'last_name' => $contact['last_name'],
                        'date_entered' => $contact['date_entered'], 'created_by' => $contact['created_by'],
                        'created_by_name' => $contact['rel_created_by_name_first_name'] . ' ' . $contact['rel_created_by_name_last_name'],
                        'description' => $contact['description'],
                        'parent_name' => $contact['account_name'], 'parent_id' => $contact['account_id'], 'parent_module' => 'Accounts',
                        'email' => $contact['email1'], 'lead_source' => $contact['lead_source'],
                        'assigned_user_id' => $contact['assigned_user_id'],
                        'assigned_user_name' => $contact['rel_assigned_user_name_first_name'] . ' ' . $contact['rel_assigned_user_name_last_name'],
                        'module' => 'Contacts'
                    );
                    $results[] = $row;
                }
            }

            if (count ($leads) > 0) {

                foreach ($leads as $lead) {

                    $array = array(
                        'id' => $lead['id'], 'name' => $lead['lead_name'],'first_name' => $lead['first_name'], 'last_name' => $lead['last_name'],
                        'date_entered' => $lead['date_entered'], 'created_by' => $lead['created_by'],
                        'created_by_name' => $lead['rel_created_by_name_first_name'] . ' ' . $lead['rel_created_by_name_last_name'],
                        'description' => $lead['description'], 'lead_source' => $lead['lead_source'],
                        'status' => $lead['status'], 'email' => $lead['email1'],
                        'account_name' => $lead['account_name'], 'account_id' => $lead['account_id'],
                        'contact_id' => $lead['contact_id'],
                        'assigned_user_id' => $lead['assigned_user_id'],
                        'assigned_user_name' => $lead['rel_assigned_user_name_first_name'] . ' ' . $lead['rel_assigned_user_name_last_name'],
                        'module' => 'Leads'
                    );
                    $results[] = $array;
                }
            }

            //Return response array with count of records and records array
            $response = array('count' => count($results), 'records'=> $results);
            return $response;
        }

        function searchSecurityGroups ($number)
        {
            global $db, $current_user;

            //Query Accounts
            $sql = "SELECT  accounts.id, accounts.name, 'Accounts' AS 'module' 
                        FROM accounts  
                          LEFT JOIN accounts_cstm ON accounts.id = accounts_cstm.id_c  
                        WHERE ((accounts_cstm.phone_office_unformatted_c like '%$number%' OR accounts_cstm.phone_alternate_unformatted_c like '%$number%' ) AND (accounts.assigned_user_id ='$current_user->id'  or  EXISTS (SELECT  1
                        FROM    securitygroups secg
                        INNER JOIN securitygroups_users secu
                        ON secg.id = secu.securitygroup_id
                        AND secu.deleted = 0
                        AND secu.user_id = '$current_user->id'
                        INNER JOIN securitygroups_records secr
                        ON secg.id = secr.securitygroup_id
                        AND secr.deleted = 0
                        AND secr.module = 'Accounts'
                        WHERE   secr.record_id = accounts.id
                        AND secg.deleted = 0) ) ) AND accounts.deleted=0";

            $GLOBALS['log']->debug($sql);
            $a_results = $db->query ($sql);

            $accounts = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($a_results)) {

                $record = BeanFactory::getBean('Accounts', $row['id']);
                $array = array(
                    'id' => $record->id, 'name' => $record->name, 'description' => $record->description ,
                    'email1' => $record->email1, 'date_entered' => $record->date_entered, 'industry' => $record->industry,
                    'account_type' => $record->account_type, 'assigned_user_id' => $record->assigned_user_id,
                    'assigned_user_name' => $record->assigned_user_name, 'created_by' => $record->created_by,
                    'created_by_name' => $record->created_by_name, 'parent_id' => $record->parent_id, 'module' => 'Accounts'
                );

                $accounts[] = $array;

            }

            //Query Contacts
            $sql = "SELECT  contacts.id, contacts.first_name, contacts.last_name, 'Contacts' AS 'module' 
                        FROM contacts  
                        
                        LEFT JOIN contacts_cstm ON contacts.id = contacts_cstm.id_c  
                        where ((contacts_cstm.phone_other_unformatted_c like '%$number%' OR contacts_cstm.phone_work_unformatted_c like '%$number%'  
                        OR contacts_cstm.phone_mobile_unformatted_c like '%$number%' OR contacts_cstm.phone_home_unformatted_c like '%$number%') 
                        
                        AND (contacts.assigned_user_id ='$current_user->id'  or  EXISTS (SELECT  1
                        FROM    securitygroups secg
                        INNER JOIN securitygroups_users secu
                            ON secg.id = secu.securitygroup_id
                            AND secu.deleted = 0
                            AND secu.user_id = '$current_user->id'
                        INNER JOIN securitygroups_records secr
                            ON secg.id = secr.securitygroup_id
                            AND secr.deleted = 0
                            AND secr.module = 'Contacts'
                        WHERE   secr.record_id = contacts.id
                        AND secg.deleted = 0) ) ) AND contacts.deleted=0";

            $GLOBALS['log']->debug($sql);
            $c_results = $db->query ($sql);

            $contacts = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($c_results)) {

                $record = BeanFactory::getBean('Contacts', $row['id']);
                $account = $record->get_linked_beans('accounts');

                $array = array(
                    'id' => $record->id, 'first_name' => $record->first_name, 'last_name' => $record->last_name,
                    'date_entered' => $record->date_entered, 'created_by' => $record->created_by,
                    'created_by_name' => $record->created_by_name, 'description' => $record->description,
                    'parent_name' => $account->name, 'parent_id' => $account->id, 'parent_module' => 'Accounts',
                    'email' => $record->email1, 'lead_source' => $record->lead_source,
                    'assigned_user_id' => $record->assigned_user_id, 'assigned_user_name' => $record->assigned_user_name,
                    'module' => 'Contacts'
                );


                $contacts[] = $array;
            }

            //Query Leads
            $sql = "SELECT  leads.id 
                        FROM leads  
                          LEFT JOIN leads_cstm ON leads.id = leads_cstm.id_c  
                        where ((leads_cstm.phone_other_unformatted_c like '%$number%' OR leads_cstm.phone_work_unformatted_c like '%$number%'  
                        OR leads_cstm.phone_mobile_unformatted_c like '%$number%' OR leads_cstm.phone_home_unformatted_c like '%$number%') 
                        
                        AND (leads.assigned_user_id ='$current_user->id'  or  EXISTS (SELECT  1
                        FROM    securitygroups secg
                        INNER JOIN securitygroups_users secu
                        ON secg.id = secu.securitygroup_id
                        AND secu.deleted = 0
                        AND secu.user_id = '$current_user->id'
                        INNER JOIN securitygroups_records secr
                        ON secg.id = secr.securitygroup_id
                        AND secr.deleted = 0
                        AND secr.module = 'Leads'
                        WHERE   secr.record_id = leads.id
                        AND secg.deleted = 0) ) ) AND leads.deleted=0";

            $GLOBALS['log']->debug($sql);
            $l_results = $db->query ($sql);

            $leads = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($l_results)) {

                $record = BeanFactory::getBean('Leads', $row['id']);

                /*               $array = array(
                                   'id' => $record->id, 'date_entered' => $record->date_entered, 'created_by' => $record->created_by,
                                   'created_by_name' => $record->created_by_name, 'description' => $record->description,
                                   'lead_source' => $record->lead_source, 'status' => $record->status,
                                   'account_name' => $record->account_name, 'account_id' => $record->account_id,
                                   'contact_id' => $record->contact_id, 'assigned_user_id' => $record->assigned_user_id,
                                   'assigned_user_name' => $record->assigned_user_name, 'module' => 'Leads'
                               );*/

                $array = array(
                    'id' => $record->id, 'first_name' => $record->first_name, 'last_name' => $record->last_name,
                    'date_entered' => $record->date_entered, 'created_by' => $record->created_by,
                    'created_by_name' => $record->created_by_name, 'description' => $record->description,
                    'lead_source' => $record->lead_source, 'status' => $record->status,
                    'email' => $record->email1,
                    'account_name' => $record->account_name, 'account_id' => $record->account_id,
                    'contact_id' => $record->contact_id, 'assigned_user_id' => $record->assigned_user_id,
                    'assigned_user_name' => $record->assigned_user_name, 'module' => 'Leads'
                );

                $leads[] = $array;
            }


            $results = array();

            if (count ($accounts) > 0) {
                foreach ($accounts as $account) {
                    $results[] = $account;
                }
            }

            if (count ($contacts) > 0) {
                foreach ($contacts as $contact) {

                    $results[] = $contact;
                }
            }

            if (count ($leads) > 0) {
                foreach ($leads as $lead) {
                    $lead['module'] = 'Leads';
                    $results[] = $lead;
                }
            }


            $response = array('count' => count($results), 'records'=> $results);
            return $response;

        }

        function searchAll ($number)
        {
            global $db;

            //Query Accounts
            $sql = "SELECT accounts.* ,accounts_cstm.*,
                    CONCAT(users_au.first_name,' ', users_au.last_name) AS 'assigned_user_name',
                    CONCAT(users_cbu.first_name, ' ', users_cbu.last_name) AS 'created_by_name' ,
                    ea.email_address AS 'email1'
                    
                    FROM accounts
                    LEFT JOIN accounts_cstm ON accounts.id = accounts_cstm.id_c
                    LEFT JOIN users users_au ON users_au.id = accounts.assigned_user_id
                    LEFT JOIN users users_cbu ON users_cbu.id = accounts.created_by
                    LEFT JOIN email_addr_bean_rel eab ON accounts.id = eab.bean_id AND bean_module = 'Accounts' AND eab.primary_address =1
                    LEFT JOIN email_addresses ea ON eab.email_address_id = ea.id                    
                    WHERE (
                            accounts_cstm.phone_office_unformatted_c LIKE '%$number%'
                            OR accounts_cstm.phone_alternate_unformatted_c LIKE '%$number%' )
                          AND accounts.deleted=0;";

            $GLOBALS['log']->debug($sql);
            $a_results = $db->query ($sql);

            $accounts = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($a_results)) {

                $array = array(
                    'id' => $row['id'], 'name' => $row['name'], 'description' => $row['description'] ,
                    'email' => $row['email1'], 'date_entered' => $row['date_entered'], 'industry' => $row['industry'],
                    'account_type' => $row['account_type'], 'assigned_user_id' => $row['assigned_user_id'],
                    'assigned_user_name' => $row['assigned_user_name'], 'created_by' => $row['created_by'],
                    'created_by_name' => $row['created_by_name'], 'parent_id' => $row['parent_id'],
                    'module' => 'Accounts'
                );

                $accounts[] = $array;

            }

            //Query Contacts
            $sql = "SELECT contacts.* ,contacts_cstm.*,
                          CONCAT(users_au.first_name,' ', users_au.last_name) AS 'assigned_user_name',
                          CONCAT(users_cbu.first_name, ' ', users_cbu.last_name) AS 'created_by_name' ,
                          ea.email_address AS 'email1', accounts.id AS account_id, accounts.name AS account_name
                        FROM contacts  
                        LEFT JOIN accounts_contacts ON contacts.id = accounts_contacts.contact_id
                        LEFT JOIN accounts ON accounts.id = accounts_contacts.account_id
                        LEFT JOIN contacts_cstm ON contacts.id = contacts_cstm.id_c
                        LEFT JOIN users users_au ON users_au.id = contacts.assigned_user_id
                        LEFT JOIN users users_cbu ON users_cbu.id = contacts.created_by
                        LEFT JOIN email_addr_bean_rel eab ON contacts.id = eab.bean_id AND bean_module = 'Contacts' AND eab.primary_address =1
                        LEFT JOIN email_addresses ea ON eab.email_address_id = ea.id  
                        WHERE (
                        contacts_cstm.phone_other_unformatted_c like '%$number%' 
                        OR contacts_cstm.phone_work_unformatted_c like '%$number%'  
                        OR contacts_cstm.phone_mobile_unformatted_c like '%$number%' 
                        OR contacts_cstm.phone_home_unformatted_c like '%$number%') 
                        AND contacts.deleted = 0";

            $GLOBALS['log']->debug($sql);
            $c_results = $db->query ($sql);

            $contacts = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($c_results)) {

                $array = array(
                    'id' => $row['id'], 'first_name' => $row['first_name'], 'last_name' => $row['last_name'],
                    'date_entered' => $row['date_entered'], 'created_by' => $row['created_by'],
                    'created_by_name' => $row['created_by_name'], 'description' => $row['description'],
                    'parent_name' => $row['account_name'], 'parent_id' => $row['account_id'], 'parent_module' => 'Accounts',
                    'email' => $row['email1'], 'lead_source' => $row['lead_source'],
                    'assigned_user_id' => $row['assigned_user_id'], 'assigned_user_name' => $row['assigned_user_name'],
                    'module' => 'Contacts'
                );

                $contacts[] = $array;

            }

            //Query Leads
            $sql = "SELECT leads.* ,leads_cstm.*,
                          CONCAT(users_au.first_name,' ', users_au.last_name) AS 'assigned_user_name',
                          CONCAT(users_cbu.first_name, ' ', users_cbu.last_name) AS 'created_by_name' ,
                          ea.email_address AS 'email1' 
                        FROM leads  
                        LEFT JOIN leads_cstm ON leads.id = leads_cstm.id_c
                        LEFT JOIN users users_au ON users_au.id = leads.assigned_user_id
                        LEFT JOIN users users_cbu ON users_cbu.id = leads.created_by
                        LEFT JOIN email_addr_bean_rel eab ON leads.id = eab.bean_id AND bean_module = 'Leads' AND eab.primary_address =1
                        LEFT JOIN email_addresses ea ON eab.email_address_id = ea.id  
                        WHERE (
                        leads_cstm.phone_other_unformatted_c like '%$number%' 
                        OR leads_cstm.phone_work_unformatted_c like '%$number%'  
                        OR leads_cstm.phone_mobile_unformatted_c like '%$number%' 
                        OR leads_cstm.phone_home_unformatted_c like '%$number%')                     
                         AND leads.deleted=0";

            $GLOBALS['log']->debug($sql);
            $l_results = $db->query ($sql);

            $leads = array();

            //Loop through results and use Bean to build array
            while($row = $db->fetchByAssoc ($l_results)) {

                $array = array(
                    'id' => $row['id'], 'first_name' => $row['first_name'], 'last_name' => $row['last_name'],
                    'date_entered' => $row['date_entered'], 'created_by' => $row['created_by'],
                    'created_by_name' => $row['created_by_name'], 'description' => $row['description'],
                    'lead_source' => $row['lead_source'], 'status' => $row['status'], 'email' => $row['email1'],
                    'account_name' => $row['account_name'], 'account_id' => $row['account_id'],
                    'contact_id' => $row['contact_id'], 'assigned_user_id' => $row['assigned_user_id'],
                    'assigned_user_name' => $row['assigned_user_name'], 'module' => 'Leads'
                );

                $leads[] = $array;

            }

            $results = array();

            if (count ($accounts) > 0) {
                foreach ($accounts as $account) {

                    $results[] = $account;
                }
            }

            if (count ($contacts) > 0) {
                foreach ($contacts as $contact) {

                    $results[] = $contact;
                }
            }

            if (count ($leads) > 0) {
                foreach ($leads as $lead) {

                    $results[] = $lead;
                }
            }


            //Return array with count of records and array of found records
            $response = array('count' => count($results), 'records'=> $results);
            return $response;
        }
    }
