<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 12/12/16
     * Time: 9:22 PM
     * File Name: tenfoldSearchApi.php
     * Project: Tenfold Number Search
     */


    class tenfoldSearchApi extends SugarApi
    {

        public function registerApiRest()
        {
            return array(
                'tenfoldSearchResults' => array(
                    'reqType' => 'GET',
                    'noLoginRequired' => false,
                    'path' => array('Tenfold','recordSearch','?'),
                    'pathVars' => array('connector','method','number'),
                    'method' => 'searchRecords',
                    'shortHelp' => 'Search unformatted numbers in modules',
                    'longHelp' => 'custom/include/api/help/tenfold_search.html',
                ),
            );
        }

        function searchRecords($api, $args)
        {

            $number = $args['number'];
            require_once('custom/include/Tenfold/TenfoldPhoneHelper.php');
            $helper = new TenfoldPhoneHelper();
            $results = $helper->searchNumber($number);

            return $results;

        }
    }