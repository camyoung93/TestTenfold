<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 1/4/17
     * Time: 1:39 PM
     * File Name: soap.php
     * Project: Tenfold Number Search
     */

    chdir('../../..');
    require_once('SugarWebServiceImplv4_1_custom.php');
    $webservice_class = 'SugarSoapService2';
    $webservice_path = 'service/v2/SugarSoapService2.php';
    $webservice_impl_class = 'SugarWebServiceImplv4_1_custom';
    $registry_class = 'registry_v4_1_custom';
    $registry_path = 'custom/service/v4_1_custom/registry.php';
    $location = 'custom/service/v4_1_custom/soap.php';
    require_once('service/core/webservice.php');