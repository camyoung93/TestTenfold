<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 1/4/17
     * Time: 1:37 PM
     * File Name: registry.php
     * Project: Tenfold Number Search
     */

    require_once('service/v4_1/registry.php');
    class registry_v4_1_custom extends registry_v4_1
    {
        protected function registerFunction()
        {
            parent::registerFunction();
            $this->serviceClass->registerFunction('tenfoldNumberSearch', array('session'=>'xsd:string'), array('return'=>'xsd:string'));
        }
    }