﻿<?php
    /**
     * User: shad
     * Date: 12/10/16
     * Time: 2:00 PM
     * File Name: manifest.php
     * Project: Tenfold Number Search
     */

    global $sugar_version;

    $manifest = array (
        'key' => 'tenfold00106',
        'name' => 'Tenfold Number Fields',
        'description' => '',
        'author' => 'Shad Mickelberry',
        'version' => '1.6',
        'is_uninstallable' => true,
        'published_date' => '2017-01-04 14:15:12',
        'type' => 'module',
        'acceptable_sugar_versions' =>
            array (
                //or
                'exact_matches' => array(
                    '7.7.0.0',
                ),
                'regex_matches' => array(
                    0 => '6\\.5\\.(.*?)',
                    1 => '6\\.7\\.(.*?)',
                    2 => '7\\.(.*?)\\.(.*?)',
                    3 => '7\\.(.*?)\\.(.*?)\\.(.*?)',

                ),
            ),
        'acceptable_sugar_flavors' =>
            array(
                'CE',
                'PRO',
                'CORP',
                'ENT',
                'ULT'
            ),
        'readme' => '',
        'icon' => '',
        'remove_tables' => '',
    );

    $installdefs['language'] = array(
        array(
            'from' => '<basepath>/files/Accounts/en_us.unformattedFields.php',
            'to_module' => 'Accounts',
            'language' => 'en_us'
        ),
        array(
            'from' => '<basepath>/files/Contacts/en_us.unformattedFields.php',
            'to_module' => 'Contacts',
            'language' => 'en_us'
        ),
        array(
            'from' => '<basepath>/files/Leads/en_us.unformattedFields.php',
            'to_module' => 'Leads',
            'language' => 'en_us'
        )
    );

    $installdefs['logic_hooks'] = array(

        array(
            'module' => 'Accounts',
            'hook' => 'after_save',
            'order' => 96,
            'description' => 'Save standard phone numbers as unformatted',
            'file' => 'custom/modules/Accounts/LogicHooks/unformatPhoneNumbers.php',
            'class' => 'TenfoldAccounts',
            'function' => 'unformatNumbers',
        ),
        array(
            'module' => 'Contacts',
            'hook' => 'after_save',
            'order' => 96,
            'description' => 'Save standard phone numbers as unformatted',
            'file' => 'custom/modules/Contacts/LogicHooks/unformatPhoneNumbers.php',
            'class' => 'TenfoldContacts',
            'function' => 'unformatNumbers',
        ),
        array(
            'module' => 'Leads',
            'hook' => 'after_save',
            'order' => 96,
            'description' => 'Save standard phone numbers as unformatted',
            'file' => 'custom/modules/Leads/LogicHooks/unformatPhoneNumbers.php',
            'class' => 'TenfoldLeads',
            'function' => 'unformatNumbers',
        ),

    );

    if (version_compare($sugar_version,'7.0', '>=')) {
        $installdefs['copy'] = array(
            array(
                'from' => '<basepath>/files/TenfoldPhoneHelper.php',
                'to' => 'custom/include/Tenfold/TenfoldPhoneHelper.php',
            ),
            array(
                'from' => '<basepath>/files/searchRecords.php',
                'to' => 'custom/include/Tenfold/searchRecords.php',
            ),
            array(
                'from' => '<basepath>/files/tenfold_phone_search_entry_point_register.php',
                'to' => 'custom/Extension/application/Ext/EntryPointRegistry/tenfold_phone_search_entry_point_register.php',
            ),
            array(
                'from' => '<basepath>/files/tenfold_search.html',
                'to' => 'custom/include/api/help/tenfold_search.html',
            ),
            array(
                'from' => '<basepath>/files/tenfoldSearchApi.php',
                'to' => 'custom/clients/base/api/tenfoldSearchApi.php',
            ),
            array(
                'from' => '<basepath>/files/Accounts/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Accounts/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/Contacts/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Contacts/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/Leads/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Leads/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/registry.php',
                'to' => 'custom/service/v4_1_custom/registry.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/rest.php',
                'to' => 'custom/service/v4_1_custom/rest.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/soap.php',
                'to' => 'custom/service/v4_1_custom/soap.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
                'to' => 'custom/service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
            ),

        );
    } else {
        $installdefs['copy'] = array(
            array(
                'from' => '<basepath>/files/TenfoldPhoneHelper.php',
                'to' => 'custom/include/Tenfold/TenfoldPhoneHelper.php',
            ),
            array(
                'from' => '<basepath>/files/searchRecords.php',
                'to' => 'custom/include/Tenfold/searchRecords.php',
            ),
            array(
                'from' => '<basepath>/files/tenfold_phone_search_entry_point_register.php',
                'to' => 'custom/Extension/application/Ext/EntryPointRegistry/tenfold_phone_search_entry_point_register.php',
            ),
            array(
                'from' => '<basepath>/files/Accounts/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Accounts/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/Contacts/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Contacts/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/Leads/unformatPhoneNumbers.php',
                'to' => 'custom/modules/Leads/LogicHooks/unformatPhoneNumbers.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/registry.php',
                'to' => 'custom/service/v4_1_custom/registry.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/rest.php',
                'to' => 'custom/service/v4_1_custom/rest.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/soap.php',
                'to' => 'custom/service/v4_1_custom/soap.php',
            ),
            array(
                'from' => '<basepath>/files/custom/service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
                'to' => 'custom/service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
            ),

        );
    }


    $installdefs['custom_fields'] = array(

        array(
            'name' => 'phone_office_unformatted_c',
            'label' => 'LBL_PHONE_OFFICE_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Accounts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_alternate_unformatted_c',
            'label' => 'LBL_PHONE_ALTERNATE_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Accounts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),

        ),

        array(
            'name' => 'phone_other_unformatted_c',
            'label' => 'LBL_PHONE_OTHER_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Contacts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_work_unformatted_c',
            'label' => 'LBL_PHONE_WORK_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Contacts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_mobile_unformatted_c',
            'label' => 'LBL_PHONE_MOBILE_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Contacts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_home_unformatted_c',
            'label' => 'LBL_PHONE_HOME_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Contacts',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),

        array(
            'name' => 'phone_other_unformatted_c',
            'label' => 'LBL_PHONE_OTHER_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Leads',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_work_unformatted_c',
            'label' => 'LBL_PHONE_WORK_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Leads',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_mobile_unformatted_c',
            'label' => 'LBL_PHONE_MOBILE_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Leads',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
        array(
            'name' => 'phone_home_unformatted_c',
            'label' => 'LBL_PHONE_HOME_UNFORMATTED',
            'type' => 'varchar',
            'max_size' => '25',
            'default_value' => '',
            'module' => 'Leads',

            'help' => 'Unformatted Phone Number with no Characters',
            'comment' => 'Unformatted Phone Number with no Characters',
            'mass_update' => false,
            'required' => false,
            'reportable' => false,
            'audited' => false,
            'duplicate_merge' => false,
            'importable' => 'true',
            'full_text_search'=> array (
                'enabled' => true,
                'boost' => '1',
                'searchable' => true,
            ),
        ),
    );