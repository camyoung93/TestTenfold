<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 9/27/16
     * Time: 9:27 AM
     * File Name: post_install.php
     * Project: Tenfold Number Search
     */

    if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');
    // /scripts/post_install.php

    function post_install() {
        $autoexecute = false; //execute the SQL
        $show_output = true; //output to the screen
        require_once("modules/Administration/QuickRepairAndRebuild.php");
        $randc = new RepairAndClear();
        $randc->repairAndClearAll(array('clearAll'),array(translate('LBL_ALL_MODULES')), $autoexecute,$show_output);

        global $db, $sugar_config;

        $sql = "INSERT INTO accounts_cstm
                (id_c) SELECT id FROM accounts WHERE id NOT IN (SELECT id_c FROM accounts_cstm);";
        $db->query($sql);

        $sql = "INSERT INTO contacts_cstm
                (id_c) SELECT id FROM contacts WHERE id NOT IN (SELECT id_c FROM contacts_cstm);";
        $db->query($sql);

        $sql = "INSERT INTO leads_cstm
                (id_c) SELECT id FROM leads WHERE id NOT IN (SELECT id_c FROM leads_cstm);";
        $db->query($sql);

        $sql = "UPDATE accounts_cstm ac
  JOIN accounts a ON ac.id_c = a.id
SET
  ac.phone_office_unformatted_c = CONCAT(
            IF (SUBSTRING(a.phone_office, 01, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 01, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 02, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 02, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 03, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 03, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 04, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 04, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 05, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 05, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 06, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 06, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 07, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 07, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 08, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 08, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 09, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 09, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 10, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 10, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 11, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 11, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 12, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 12, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 13, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 13, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 14, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 14, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 15, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 15, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 16, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 16, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 17, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 17, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 18, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 18, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 19, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 19, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 20, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 20, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 21, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 21, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 22, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 22, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 23, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 23, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 24, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 24, 1), '')
            ,   IF (SUBSTRING(a.phone_office, 25, 1) REGEXP '[0-9]', SUBSTRING(a.phone_office, 25, 1), '')
            )
  , ac.phone_alternate_unformatted_c = CONCAT(
           IF (SUBSTRING(a.phone_alternate, 01, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 01, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 02, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 02, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 03, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 03, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 04, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 04, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 05, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 05, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 06, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 06, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 07, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 07, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 08, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 08, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 09, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 09, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 10, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 10, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 11, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 11, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 12, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 12, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 13, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 13, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 14, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 14, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 15, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 15, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 16, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 16, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 17, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 17, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 18, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 18, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 19, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 19, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 20, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 20, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 21, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 21, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 22, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 22, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 23, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 23, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 24, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 24, 1), '')
           ,   IF (SUBSTRING(a.phone_alternate, 25, 1) REGEXP '[0-9]', SUBSTRING(a.phone_alternate, 25, 1), '')
     )";

        $db->query($sql);

        $sql = "UPDATE contacts_cstm lc
                  JOIN contacts l ON lc.id_c = l.id
                SET
                  lc.phone_other_unformatted_c = CONCAT(
                      IF (SUBSTRING(l.phone_other, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 25, 1), '')
                      )
                  , lc.phone_work_unformatted_c =  CONCAT(
                      IF (SUBSTRING(l.phone_work, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 25, 1), '')
                      )
                  , lc.phone_mobile_unformatted_c = CONCAT(
                  IF (SUBSTRING(l.phone_mobile, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 25, 1), '')
                
                ) 
                  , lc.phone_home_unformatted_c = CONCAT(
                      IF (SUBSTRING(l.phone_home, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 25, 1), '')
                      ) ";

        $db->query($sql);

        $sql = "UPDATE leads_cstm lc
                  JOIN leads l ON lc.id_c = l.id
                SET
                  lc.phone_other_unformatted_c = CONCAT(
                      IF (SUBSTRING(l.phone_other, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_other, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_other, 25, 1), '')
                      )
                  , lc.phone_work_unformatted_c =  CONCAT(
                      IF (SUBSTRING(l.phone_work, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_work, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_work, 25, 1), '')
                  )
                  , lc.phone_mobile_unformatted_c = CONCAT(
                  IF (SUBSTRING(l.phone_mobile, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_mobile, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_mobile, 25, 1), '')
                      )
                  , lc.phone_home_unformatted_c = CONCAT(
                      IF (SUBSTRING(l.phone_home, 01, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 01, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 02, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 02, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 03, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 03, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 04, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 04, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 05, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 05, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 06, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 06, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 07, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 07, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 08, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 08, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 09, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 09, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 10, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 10, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 11, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 11, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 12, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 12, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 13, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 13, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 14, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 14, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 15, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 15, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 16, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 16, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 17, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 17, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 18, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 18, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 19, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 19, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 20, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 20, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 21, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 21, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 22, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 22, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 23, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 23, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 24, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 24, 1), '')
                      ,   IF (SUBSTRING(l.phone_home, 25, 1) REGEXP '[0-9]', SUBSTRING(l.phone_home, 25, 1), '')
                      )";
        $db->query($sql);

        /**
         * Leads Indexes
         */
        $indexDef = array(
            array(
                'name' => 'idx_home_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_home_unformatted_c')
            ),
            array(
                'name' => 'idx_mobile_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_mobile_unformatted_c')
            ),
            array(
                'name' => 'idx_work_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_work_unformatted_c')
            ),
            array(
                'name' => 'idx_other_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_other_unformatted_c')
            )
        );
        if (!$db->get_index('leads_cstm','idx_other_phone_unformatted')) {

            $db->addIndexes('leads_cstm', $indexDef);

        }



        /**
         * Contacts Indexes
         */
        $indexDef = array(
            array(
                'name' => 'idx_home_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_home_unformatted_c')
            ),
            array(
                'name' => 'idx_mobile_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_mobile_unformatted_c')
            ),
            array(
                'name' => 'idx_work_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_work_unformatted_c')
            ),
            array(
                'name' => 'idx_other_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_other_unformatted_c')
            )
        );


        if (!$db->get_index('contacts_cstm','idx_other_phone_unformatted')) {

            $db->addIndexes('contacts_cstm', $indexDef);

        }
        /**
         * Accounts Indexes
         */
        $indexDef = array(
            array(
                'name' => 'idx_home_office_unformatted',
                'type' => 'index',
                'fields' => array('phone_office_unformatted_c')
            ),
            array(
                'name' => 'idx_alternate_phone_unformatted',
                'type' => 'index',
                'fields' => array('phone_alternate_unformatted_c')
            ),

        );

        if (!$db->get_index('accounts_cstm','idx_alternate_phone_unformatted')) {

            $db->addIndexes('accounts_cstm', $indexDef);

        }


        if (is_array($sugar_config['full_text_engine']['Elastic'])) {

            try {
                require_once('src/SearchEngine/SearchEngine.php');
                require_once('src/SearchEngine/Engine/Elastic.php');

                $engine = new \Sugarcrm\Sugarcrm\SearchEngine\Engine\Elastic();
                $search = new Sugarcrm\Sugarcrm\SearchEngine\SearchEngine($engine);
                $result = $search::getInstance()->scheduleIndexing(array('Accounts','Contacts', 'Leads'), 1);

            } catch (Exception $e) {
                $result = false;
                $errors = $e->getMessage();
            }

            if (!$result) {
                echo "
                <script>
                var app = window.parent.SUGAR.App;
                window.parent.SUGAR.App.sync({callback: function(){
                    app.router.navigate('#bwc/index.php?module=Administration&action=GlobalSearchSettings', {trigger:true});
                    app.alert.show('index_error', 
                    {level: 'error', 
                    title: 'Error Scheduling Index', 
                    messages: ' Forwarding to Search Admin to check settings and schedule global search index',
                    autoClose: false});
                }});
                
                </script>"
                ;
            }
        }
    }